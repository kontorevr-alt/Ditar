const imgDialog = document.querySelector(".img-dialog");
const imgDialogContent = document.querySelector(".img-dialog-content");
const imgDialogClose = document.querySelector(".img-dialog-close");
const viewer = document.querySelector(".viewer");
const prevBtn = document.querySelector(".prev");
const nextBtn = document.querySelector(".next");

async function openImgs() {
    let images = []
    let current = 0;
    async function updateImage() {
        viewer.src = images[current];
    }
    imgDialog.showModal();
    this.querySelectorAll("img").forEach(img => {
        images.push(img.src)
    });

    nextBtn.onclick = async () => {
        current++
        if (current >= images.length) current = 0;
        updateImage();
    };
    prevBtn.onclick = async () => {
        current--;
        if (current < 0) current = images.length - 1;
        updateImage();
    };

    updateImage();
}

imgDialogClose.addEventListener('click', async () => {
    imgDialog.close();
});

async function createProject(data) {
    let cur = 0;
    const container = document.querySelector(".projects-container")

    const projectDiv = document.createElement("div");
    projectDiv.className = "project-div";

    const imgs = document.createElement("div");
    imgs.className = "project-imgs";
    imgs.onclick = async function () {openImgs.call(this);};

    data.imgs.forEach(src => {
        const img = document.createElement("img");
        img.src = src;
        img.draggable = false;
        if (cur != 0) {
            img.style = 'display: none;'
        }

        cur++

        imgs.appendChild(img);
    });

    const name = document.createElement("label");
    name.className = "project-name";
    name.textContent = data.name;

    const line = document.createElement("canvas");
    line.className = "thin-black-line";

    const desc = document.createElement("h3");
    desc.className = "project-desc";
    desc.textContent = data.desc;

    const client = document.createElement("p");
    client.className = "project-client";
    client.textContent = data.client;

    projectDiv.appendChild(imgs);
    projectDiv.appendChild(name);
    projectDiv.appendChild(line);
    projectDiv.appendChild(desc);
    projectDiv.appendChild(client);
    container.appendChild(projectDiv);
}

fetch("/api/projects")
    .then(r => r.json())
    .then(async files => {
        files.forEach(async file => {
            fetch(`/api/projects/${file}`)
                .then(r => r.json())
                .then(async data => {
                    await createProject(data)
                })
                .catch(err => console.error(err));
        });
        console.log(data)
    });
