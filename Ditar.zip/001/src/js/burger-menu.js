const navdock = document.getElementById('navdock');
const burger  = document.getElementById('burger');
const backdrop = document.getElementById('backdrop');
const menu = document.getElementById('menu');

const setOpen = (open) => {
    navdock.dataset.open = String(open);
    burger.setAttribute('aria-expanded', String(open));
    backdrop.dataset.open = String(open);
};

burger.addEventListener('click', (e) => {
    e.stopPropagation();
    setOpen(navdock.dataset.open !== 'true');
});

// клик вне — закрыть
backdrop.addEventListener('click', () => setOpen(false));
document.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') setOpen(false);
});

// не закрывать, если кликаем внутри меню
menu.addEventListener('click', (e) => e.stopPropagation());
document.addEventListener('click', () => setOpen(false));