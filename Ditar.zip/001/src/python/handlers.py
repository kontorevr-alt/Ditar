from aiogram import Bot, Dispatcher, types, F
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, LabeledPrice
from aiogram.fsm.storage.memory import MemoryStorage
from aiogram.filters import Command
import asyncio
from src.python.utils import TG
from src.python.cfg import TOKEN

bot = Bot(token=TOKEN)
dp = Dispatcher()

@dp.message(Command("start"))
async def start(message: types.Message):
    await TG.start(message)
    
@dp.message(lambda message: message.photo)
async def handle_photo(message: types.Message):
    await TG.photo(message)

@dp.message(lambda message: message.document)
async def handle_document(message: types.Message):
    await TG.json(message)
    
@dp.callback_query(F.data)
async def callback_handler(callback_query: types.CallbackQuery):
    await TG.cb(callback_query)