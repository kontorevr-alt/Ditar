from aiogram import types
from aiogram.types import InlineKeyboardMarkup, InlineKeyboardButton, FSInputFile

class TG:
    async def start(message: types.Message):
        mrk = InlineKeyboardMarkup(
            inline_keyboard=[
                [
                    InlineKeyboardButton(text='1️⃣ О боте', callback_data='menu_bot_doc'),
                    InlineKeyboardButton(text='2️⃣ О сайте', callback_data='menu_web_doc')
                ],
                [
                    InlineKeyboardButton(text="3️⃣ Пример json'а", callback_data='menu_json_temple'),
                    InlineKeyboardButton(text='4️⃣ О нас', callback_data='menu_about')
                ]
            ]
        )
        
        await message.answer(f'👋 Хало, ниже список возможностей этого бота, пользуйся)', reply_markup=mrk)
    
    async def photo(message: types.Message):
        photo = message.photo[-1]
        
        file = await message.bot.get_file(photo.file_id)
        file_path = file.file_path
        
        await message.bot.download_file(file_path, f"projects/imgs/{message.caption}.jpg")
        
        await message.answer("Фото получено!")
        
    async def json(message: types.Message):
        file = await message.bot.get_file(message.document.file_id)
        file_path = file.file_path

        await message.bot.download_file(file_path, f"projects/{message.document.file_name}")
        
        await message.answer("Json получен!")

    async def cb(callback_query: types.CallbackQuery):
        cq = callback_query
        if cq.data == 'main_menu':
            mrk = InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(text='1️⃣ О боте', callback_data='menu_bot_doc'),
                        InlineKeyboardButton(text='2️⃣ О сайте', callback_data='menu_web_doc')
                    ],
                    [
                        InlineKeyboardButton(text="3️⃣ Пример json'а", callback_data='menu_json_temple'),
                        InlineKeyboardButton(text='4️⃣ О нас', callback_data='menu_about')
                    ]
                ]
            )
            
            await cq.message.edit_text(f'👋 Хало, ниже список возможностей этого бота, пользуйся)', reply_markup=mrk)
        elif cq.data == 'menu_bot_doc':
            mrk = InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(text='◀️ В главное меню', callback_data='main_menu')
                    ]
                ]
            )
            
            await cq.message.edit_text(f'Чтобы загрузить проект отправьте одно изображение с текстом, которое будет названием фотографии на сервере. Далее отправьте конфигурационный json файл.\n❗❗ ИМЯ JSON ФАЙЛА ДОЛЖНО БЫТЬ НАЧАЛОМ ИМЕНИ ФОТОГРАФИИ\nПример: axe.json (json файл) | axe01 (изображение) | axe02 (изображение) | axe03 (изображение)', reply_markup=mrk)
        elif cq.data == 'menu_web_doc':
            mrk = InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(text='◀️ В главное меню', callback_data='main_menu')
                    ]
                ]
            )
            
            await cq.message.edit_text(f'Все файлы для проектов находятся в папке projects.', reply_markup=mrk)
        elif cq.data == 'menu_json_temple':
            await cq.message.answer_document(FSInputFile('src/python/temple.json'))
        elif cq.data == 'menu_about':
            mrk = InlineKeyboardMarkup(
                inline_keyboard=[
                    [
                        InlineKeyboardButton(text='◀️ В главное меню', callback_data='main_menu')
                    ],
                    [
                        InlineKeyboardButton(text='CKACHATb', url='https://github.com/kuzzia88')
                    ]
                ]
            )
            
            await cq.message.edit_text('Этот бот предназначен, для сайта-портфолио Ditar. Бот был создан CKACHATb', reply_markup=mrk)